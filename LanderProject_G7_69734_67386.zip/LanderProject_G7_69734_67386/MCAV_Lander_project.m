%% MCAV Lander project: State-Space analysis
clear 
clc
initPlots;
 
%Mars parameters 

g_M = 3.711;
rho = 0.02;
Cd = 1.05;

% Lander and rover details
m_total = 1051.48;
J0 = [ 1575.90,0, 0; 0, 2002.48, 0; 0, 0, 1612.57];
zI = [0;0;1];
A_z = 8.210382;
A_y =5.169781;
A_x = 6.008701;
alpha = 20*pi/180;
K1 = A_x*rho*Cd/2;
K2 = A_y*rho*Cd/2;
K3 = A_z*rho*Cd/2;

% Retrorockets position
Lx =1.509650;
Ly =1.359650;
Lz =0.464581;

P1 = [-Lx;Ly/2;Lz];
P2 = [Lx;Ly/2;Lz];
P3 = [-Lx;-Ly/2;Lz];
P4 = [Lx;-Ly/2;Lz];

%1. Lander dynamic system modeling
 % simulate nonlinear system
Dt = 0.01;
t = 0:Dt:10;
Nsim = length(t);
nx = 12;
ny = 3;
x0 = zeros(nx,1);
x = zeros(nx,Nsim);
y = zeros(ny,Nsim);
Te = -g_M*m_total;
u_NL = 2*Te/4*[1;1;1;1]*(t>=0);

figure(32);
plot(t,u_NL);
grid on;


% C matrix 
    C  = [  eye(3)    , zeros(3)   , zeros(3) , zeros(3)];

for k=1:Nsim
     % prepare variables:
    p  = x(1:3,k);
    v   = x(4:6,k);
    lbd = x(7:9,k);
    om  = x(10:12,k);
    R = Euler2R(lbd);

    %Propulsion forces
    T1=u_NL(1,k);
    T2=u_NL(2,k);
    T3=u_NL(3,k);
    T4=u_NL(4,k);
    f1 = T1 * [0;-sin(alpha);cos(alpha)];
    f2 = T2 * [0;-sin(alpha);cos(alpha)];
    f3 = T3 * [0;sin(alpha);cos(alpha)];
    f4 = T4 * [0;sin(alpha);cos(alpha)];
    fp = f1 + f2 + f3 + f4;

    np1=cross(P1,f1);
    np2=cross(P2,f2);
    np3=cross(P3,f3); 
    np4=cross(P4,f4);

    %Propulsion moment
    np = np1+np2+np3+np4;

    %aerodynamic force
    fa = [K1*(v(1))^2;K2*(v(2))^2;K3*(v(3))^2];

    % compute state derivative:
    p_dot = R*v;
    v_dot = -skew(om)*v + g_M*R'*zI +1/m_total*(fa+fp);
    lbd_dot = Euler2Q(lbd)*om;
    om_dot = -J0\skew(om)*J0*om + J0\(np);
    x_dot = [p_dot;v_dot;lbd_dot;om_dot];
    % integrate state
    x(:,k+1) = x(:,k) + Dt*x_dot; 
    % state variable computation
    v(:,k)   = x(4:6,k);
    lbd(:,k) = x(7:9,k);
    om(:,k)  = x(10:12,k);
    % compute current output:
    y(:,k) = C*x(:,k);
end

figure(33);
subplot(3,1,1)
plot(t,y(1,:));
legend('Px (nlin)')
grid on
subplot(3,1,2)
plot(t,y(2,:));
legend('Py (nlin)');
grid on
subplot(3,1,3)
plot(t,y(3,:));
legend('Pz (nlin)');
grid on

%Euler angles values
figure(34);
subplot(3,1,1)
plot(t,lbd(1,:));
title('Euler angles')
legend('roll (nlin)')
grid on
subplot(3,1,2)
plot(t,lbd(2,:));
legend('pitch (nlin)');
grid on
subplot(3,1,3)
plot(t,lbd(3,:));
legend('yaw (nlin)');
grid on

%Velocity
figure(35);
subplot(3,1,1)
plot(t,v(1,:));
title('Velocity')
legend('Vx (nlin)')
grid on
subplot(3,1,2)
plot(t,v(2,:));
legend('Vy (nlin)');
grid on
subplot(3,1,3)
plot(t,v(3,:));
legend('Vz (nlin)');
grid on

%% Model I
    % auxiliary vectors
    b1 = 1/m_total*[0;-sin(alpha);cos(alpha)];
    b2 =1/m_total*[0;sin(alpha);cos(alpha)];
    b41 = J0\[29073/36445;14257/10050;51947/100608];
    b42 = J0\[29073/36445;-14257/10050;-51947/100608];
    b43 = J0\[-29073/36445;14257/10050;-51947/100608];
    b44 = J0\[-29073/36445;-14257/10050;51947/100608];

    
    %Resultant matrices
    A3 = [  zeros(3), eye(3),   zeros(3),      zeros(3)
            zeros(3), zeros(3), skew(g_M*zI),  zeros(3)
            zeros(3), zeros(3), zeros(3),      eye(3)
            zeros(3), zeros(3), zeros(3),      zeros(3) ];

    B = [  zeros(3,1), zeros(3,1), zeros(3,1),zeros(3,1)
            b1,         b1,         b2,        b2;
            zeros(3,1), zeros(3,1), zeros(3,1),zeros(3,1);
            b41,        b42,        b43,       b44];

    D = zeros(3,4);


ve_z=89;
v_e = [0;0;ve_z];
A2_I = [  zeros(3), eye(3),                      -skew(v_e),     zeros(3)
            zeros(3), 2/m_total*K3*ve_z*diag(zI),   skew(g_M*zI),  skew(ve_z*zI)
            zeros(3), zeros(3),                     zeros(3),      eye(3)
            zeros(3), zeros(3),                     zeros(3),      zeros(3) ];

%Linear model simulation
sys_2I = ss(A2_I,B,C,D);
Te  = -g_M*m_total;
u_L = Te/4*[1;1;1;1]*(t>=0);
y_L2I = lsim(sys_2I,u_L',t,x0)';

%Plots 
figure(21);
subplot(3,1,1)
plot(t,y_L2I(1,:));
legend('Px (lin)')
grid on
subplot(3,1,2)
plot(t,y_L2I(2,:));
legend('Py (lin)');
grid on
subplot(3,1,3)
plot(t,y_L2I(3,:));
legend('Pz (lin)');
grid on

%Controlability, observability and stability
[V_2I,D_2I,W_2I] = eig(A2_I);
mode_obs2 = obsv(A2_I,C);
if rank(mode_obs2)>=size(A2_I,1)
  disp('O modelo I � observ�vel');
end
mode_ctrl2 = ctrb(A2_I,B);
if rank(mode_ctrl2)>=size(A2_I,1)
  disp('O modelo I � control�vel');
end

 figure(22);
 sigma(sys_2I);
 title('Sigma Values (Vz = 89 m/s, Vx = Vy = 0)');
 grid on;

%% Model II
ve_z=89/2;
v_e = [0;0;ve_z];
A2_II = [  zeros(3), eye(3),                      -skew(v_e),     zeros(3)
            zeros(3), 2/m_total*K3*ve_z*diag(zI),   skew(g_M*zI),  skew(ve_z*zI)
            zeros(3), zeros(3),                     zeros(3),      eye(3)
            zeros(3), zeros(3),                     zeros(3),      zeros(3) ];

%Linear model simulation
sys_2II = ss(A2_II,B,C,D);
Te  = -g_M*m_total;
u_L = Te/4*[1;1;1;1]*(t>=0);
y_L2II = lsim(sys_2II,u_L',t,x0)';

%Plots 
figure(23);
subplot(3,1,1)
plot(t,y_L2II(1,:));
legend('Px (lin)')
grid on
subplot(3,1,2)
plot(t,y_L2II(2,:));
legend('Py (lin)');
grid on
subplot(3,1,3)
plot(t,y_L2II(3,:));
legend('Pz (lin)');
grid on

%Controlability, observability and stability
[V_2II,D_2II,W_2II] = eig(A2_II);
mode_obs2 = obsv(A2_II,C);
if rank(mode_obs2)>=size(A2_II,1)
  disp('O modelo II � observ�vel');
end
mode_ctrl2 = ctrb(A2_II,B);
if rank(mode_ctrl2)>=size(A2_II,1)
  disp('O modelo II � control�vel');
end

 figure(24);
 sigma(sys_2II);
  title('Sigma Values (Vz = 44.5 m/s, Vx = Vy = 0)');
 grid on;


%% Model III

%Linear model simulation
sys3 = ss(A3,B,C,D);
y_L3 = lsim(sys3,u_L',t,x0)';


%Controlability and observability 
mode_obs3 = obsv(A3,C);
if rank(mode_obs3)>=size(A3,1)
  disp('O modelo III � observ�vel');
end
mode_ctrl3 = ctrb(A3,B);
if rank(mode_ctrl3)>=size(A3,1)
  disp('O modelo III � control�vel');
end

 %2. Nominal system control

 %2.1 Obtain the Eigenvalue decomposition
 [V_3,D_3,W_3] = eig(A3);

 %2.2 Obtain an SVD frequency analysis
 [U_3,S_3,Vv_3] = svd(A3);

 figure(6);
 sigma(sys3);
  title('Sigma Values (Vz = Vx = Vy = 0)');
 grid on;

%2.3 Design an Hinf controller

% Checking stability with LQR controller
Q = diag([0.01,0.1,1,10,100,200,300,400,500,600,700,800]);
R = diag([10,1,0.1,0.01]);
Klqr = lqr(A3,B,Q,R);
lbd_CL_lqr = eig(A3-B*Klqr); 
if any(real(lbd_CL_lqr) >= 0), disp('CL system with LQR not stable'); else, disp('CL system with LQR is stable'); end

% P matrix calculation
%dot_x = A x + B1 w + B2 u
% z = C1 x + D11 w + D12 u
% v = C2 x + D21 w + D22 u
% x = [p;v;lambda;omega]
% u = [T1;T2;T3;T4];
% w = r = [p_ref;v_ref;lambda;omega]

W1 = sqrt(Q);
W2 = sqrt(R);

B1_3 = zeros(12);
B2_3 = B;
C1_3 =  [W1;zeros(0,12)];
C2_3 = -eye(12);
D11_3 = zeros(12,12);
D12_3 =  [zeros(8,4);W2];
D21_3 = eye(12);
D22_3 = zeros(12,4);

B0_3 = [ B1_3 B2_3 ];
C0_3 = [ C1_3
         C2_3 ];
D0_3 = [D11_3 D12_3
        D21_3 D22_3];
P3 = ss(A3,B0_3,C0_3,D0_3);

% tests on P:
if (nx - rank(ctrb(A3,B2_3))) > 0, disp('A1.1 on P: system uncontrolable'); else disp('A1.1 on P: OK'); end
if (nx - rank(obsv(A3,C2_3))) > 0, disp('A1.2 on P: system unobservable'); else disp('A1.2 on P: OK'); end
if (size(D12_3,2) - rank(D12_3)) > 0, disp('A2.1 on P: D12 is column rank deficient'); else disp('A2.1 on P: OK'); end
if (size(D21_3,1) - rank(D21_3)) > 0, disp('A2.2 on P: D21 is row rank deficient'); else disp('A2.1 on P: OK'); end

syms w real; 
Aux1 = [A3 - 1i*w*eye(size(A3)) , B2_3 ; C1_3 , D12_3];
if (size(Aux1,2) - rank(Aux1)) > 0,  disp('A3 on P: matrix is column rank deficient'); else disp('A3 on P: OK'); end
Aux2 = [A3 - 1i*w*eye(size(A3)) , B1_3 ; C2_3 , D21_3];
if (size(Aux2,1) - rank(Aux2)) > 0,  disp('A4 on P: matrix is column rank deficient'); else disp('A4 on P: OK'); end

nmeas = 12;
ncont = 4;
[Kinf,CLinf,gammainf,info_inf] = hinfsyn(P3,nmeas,ncont);
poles_CLinf = pole(CLinf);
if any(real(poles_CLinf) >= 0), disp('CL system with Hinf controller not stable'); else, disp('CL system with Hinf controller is stable'); end

% % simulate controlled system
% Dt = 0.01;
% t = 0:Dt:10;
% 
% NSim = length(t);
% nx = 12;
% nu = 4;
% x = zeros(nx,NSim);
% u = zeros(nu,NSim);
% x0 = zeros(nx,1);
% x(:,1) = x0;
% 
% r = zeros(12,1)*(t>=0);
% 
% for k = 1:NSim
%     % get measurements:
%     y(:,k) = C*x(:,k);
% 
%     % Hinf controller
%            % = -[(r(:,k)-y(:,k));-x(1:4,k)];
%             v = r(1:3,k)-y(:,k);
%            % v = -[r(:,k)-y(:,k);x(1:3,k)];
%             u(:,k) = Kinf.C'*v; % approximation for LQR-like performance of Hinf
% 
%     % simulate system:
%     x_dot = A3*x(:,k) + B*u(:,k); % system derivatives
%     xp = x(:,k) + Dt*x_dot; % integrate system state
%     if k < NSim
%         x(:,k+1) = xp;
%     end
% 
% end
%% Model IV
vx_e = 5;
ve = [vx_e;0;0];

A4 = [  zeros(3), eye(3)     , -skew(ve)  , zeros(3)
        zeros(3), -2/m_total*diag([K1*vx_e,0,0])        , skew(g_M*zI), skew(ve)
        zeros(3), zeros(3)   , zeros(3)  , eye(3)
        zeros(3), zeros(3)   , zeros(3)  , zeros(3) ];
sys4 = ss(A4,B,C,D);

y_L = lsim(sys4,u_L',t,x0)';

figure(41);
subplot(3,1,1)
plot(t,y_L(1,:));
legend('Px (lin)')
grid on
subplot(3,1,2)
plot(t,y_L(2,:));
legend('Py (lin)');
grid on
subplot(3,1,3)
plot(t,y_L(3,:));
legend('Pz (lin)');
grid on

%Controlability, observability and stability
[V_4,D_4,W_4] = eig(A4);
mode_obs4 = obsv(A4,C);
if rank(mode_obs4)>=size(A4,1)
  disp('O modelo IV � observ�vel');
end
mode_ctrl4 = ctrb(A4,B);
if rank(mode_ctrl4)>=size(A4,1)
  disp('O modelo IV � control�vel');
end

 s = tf('s');
 figure(42);
 sigma(sys4);
 title('Sigma Values (Vx = 5, Vz = Vy = 0)');
 grid on;
disp('Simula��o terminada')

 