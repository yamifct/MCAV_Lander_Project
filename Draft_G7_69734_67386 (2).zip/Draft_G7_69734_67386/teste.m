z=[0;0;1];
skew(z);