%% MCAV Lander project: State-Space analysis
clear
clc
pkg load control

%% Mars parameters 
g_M = 3.711;
rho = 0.02;
Cd = 1.05;

% Lander 
m_total= 1051.48;
J = [ 1575.90,0, 0; 0, 2002.48, 0; 0, 0, 1612.57];
zI = [0;0;1];
A_f = 6.01;
alpha = 20*pi/180;

% Retrorockets position
Lx =1.509650;
Ly =1.359650;
Lz =0.464581;


P1 = [-Lx;Ly/2;Lz];
P2 = [Lx;-Ly/2;Lz];
P3 = [-Lx;Ly/2;Lz];
P4 = [Lx;-Ly/2;Lz];

%Auxiliary parameters and matrices
phi_e =0.01;
vx_e =0.75;
beta_D =rho*A_f*Cd;
x_I = [1;0;0];
R_Pv = [1,0,0;0,cos(phi_e),-sin(phi_e);0,sin(phi_e),cos(phi_e)];
M_Plambda = [0,0,0;0,0,vx_e;0,-vx_e,0];
N_vlambda =g_M*[0,-1,0;cos(phi_e),0,0;-sin(phi_e),0,0];



% Linear simulation parameters
nx = 12;
ny = 3 ;
x0 = zeros(nx,1);
Dt = 0.01;
t = 0:Dt:10;

A4 = [  zeros(3), R_Pv     , M_Plambda  , zeros(3)
        zeros(3), 2*beta_D*vx_e/m_total*diag(x_I)        , N_vlambda, -M_Plambda
        zeros(3), zeros(3)   , zeros(3)  , R_Pv
        zeros(3), zeros(3)   , zeros(3)  , zeros(3) ];
B4 = [   zeros(3); 1/m_total*eye(3);zeros(3);zeros(3)];
C4 = [   eye(3)    , zeros(3)   , zeros(3) , zeros(3)  ];
D4 = zeros(3);
sys = ss(A4,B4,C4,D4);
u_e = 2*m_total*g_M*eye(3)*zI;
Te  =  g_M*m_total;
u_L = [Te*cos(alpha);0;Te*sin(alpha)]*(t>=0);
y_L = lsim(sys,u_L',t,x0)'; 

%Controlability, observability and stability
[V_4,D_4,W_4] = eig(A4);
mode_obs4 = obsv(A4,C4);
if rank(mode_obs4)>=size(A4,1)
  disp('O modelo 4 � observ�vel');
  end
mode_ctrl4 = ctrb(A4,B4);
if rank(mode_ctrl4)>=size(A4,1)
  disp('O modelo 4 � control�vel');
  end

  % simulate nonlinear system
Nsim = length(t);
x = zeros(nx,Nsim);
y = zeros(ny,Nsim);
u_NL = u_e*ones(size(t)) + u_L;
x(:,1) = x0;

for k=1:Nsim
     % prepare variables:
    p   = x(1:3,k);
    v   = x(4:6,k);
    lbd = x(7:9,k);
    om  = x(10:12,k);
    R = Euler2R(lbd);
    
    %Propulsion forces 
    T = norm(u_NL(:,k));
    T1=T/4;
    T2=T1;
    T3=T1;
    T4=T1;
    f1 = T1 * [-cos(alpha);0;sin(alpha)];
    f2 = T2 * [cos(alpha);0;sin(alpha)];
    f3 = T3 * [-cos(alpha);0;sin(alpha)];
    f4 = T4 * [cos(alpha);0;sin(alpha)];
    fp = f1 + f2 + f3 + f4;
    
   
    %Propulsion moment
    np1=cross(P1,f1);
    np2=cross(P2,f2);
    np3=cross(P3,f3); 
    np4=cross(P4,f4);
    np = np1+np2+np3+np4;
    
    %Drag force
    Drag = (beta_D/2)*(v(1))^2;
    % compute state derivative:
    p_dot = R*v;
    v_dot = -skew(om)*v + g_M*R'*zI +1/m_total*(Drag+fp);
    lbd_dot = Euler2Q(lbd)*om;
    om_dot = -inv(J)*skew(om)*J*om + inv(J)*(np);
    x_dot = [p_dot;v_dot;lbd_dot;om_dot];
    % integrate state
    x(:,k+1) = x(:,k) + Dt*x_dot;
    % compute current output:
    y(:,k) = C4*x(:,k);
  end
figure(1);
plot(t,y_L(1:3,:),'--');
legend('p_x (lin)','p_y (lin)','p_z (lin)');
grid on
figure(2)
plot(t,y(1:3,:),'-.');
legend('p_x (nlin)','p_y (nlin)','p_z (nlin)');
grid on;
figure(3);
plot(t,u_L);
grid on;
#disp('Simula��o terminada')

%Controlability, observability and stability
Vp4=eig(A4);
##
##mode_obs4 = obsv(A4,C4);
##if rank(mode_obs4)>=size(A4,1)
##  disp('O modelo 4 � observ�vel');
##  end
##mode_ctrl4 = ctrb(A4,B4);
##if rank(mode_ctrl4)>=size(A4,1)
##  disp('O modelo 4 � control�vel');
##  end
AA=rank(mode_obs4);
BB=size(A4,1);
